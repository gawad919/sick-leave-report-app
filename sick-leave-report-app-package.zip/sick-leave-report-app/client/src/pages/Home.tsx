import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { Download, FileDown, FileText, Languages, Link2, Menu, Pencil, Plus, Save, Search, Settings2, Share2, SlidersHorizontal, Upload, X } from "lucide-react";
import { trpc } from "@/lib/trpc";

const BG_DEFAULT = "/assets/report-background.png";
const LOGO_DEFAULT = "/assets/seha_logo.png";

const fieldLabels: Record<string, string> = {
  identityNumber: "رقم الهوية / الإقامة",
  patientNameAr: "اسم المريض بالعربي",
  patientNameEn: "اسم المريض بالإنجليزي",
  nationalityAr: "الجنسية بالعربي",
  nationalityEn: "الجنسية بالإنجليزي",
  employerAr: "جهة العمل بالعربي",
  employerEn: "جهة العمل بالإنجليزي",
  doctorNameAr: "اسم الممارس بالعربي",
  doctorNameEn: "اسم الممارس بالإنجليزي",
  jobTitleAr: "المسمى الوظيفي بالعربي",
  jobTitleEn: "المسمى الوظيفي بالإنجليزي",
};

type ReportData = {
  reportNumber: string;
  sector: "government" | "private";
  durationDays: number;
  startDate: string;
  endDate: string;
  issueDate: string;
  startHijri: string;
  endHijri: string;
  printTime: string;
  printDate: string;
  identityNumber: string;
  patientNameAr: string;
  patientNameEn: string;
  nationalityAr: string;
  nationalityEn: string;
  employerAr: string;
  employerEn: string;
  doctorNameAr: string;
  doctorNameEn: string;
  jobTitleAr: string;
  jobTitleEn: string;
  facilityNameAr: string;
  facilityNameEn: string;
  visibleLinkTextAr: string;
  visibleLinkTextEn: string;
  hiddenLinkUrl: string;
  barcodeUrl: string;
  customFields: { labelAr: string; labelEn: string; valueAr: string; valueEn: string }[];
};

type Settings = {
  backgroundUrl: string;
  hospitalLogoUrl: string;
  barcodeUrl: string;
  facilityNameAr: string;
  facilityNameEn: string;
  verifyTargetUrl: string;
  visibleLinkTextAr: string;
  visibleLinkTextEn: string;
  englishFontFamily: string;
  englishFontSize: number;
  englishFontWeight: number;
  englishDirection: "ltr" | "rtl";
  englishAlign: "left" | "center" | "right";
  englishOffsetX: number;
  englishOffsetY: number;
  arabicOffsetX: number;
  arabicOffsetY: number;
  logoWidth: number;
  logoOffsetX: number;
  logoOffsetY: number;
  barcodeWidth: number;
  barcodeOffsetX: number;
  barcodeOffsetY: number;
  hideGuideLines: boolean;
  customFieldDefinitions: { labelAr: string; labelEn: string }[];
};

const defaultSettings: Settings = {
  backgroundUrl: BG_DEFAULT,
  hospitalLogoUrl: LOGO_DEFAULT,
  barcodeUrl: "",
  facilityNameAr: "مستشفى الملك سلمان بالرياض",
  facilityNameEn: "King Salman Hospital In Riyadh",
  verifyTargetUrl: "https://seha.sa/#/i/inquiries/slenquiry",
  visibleLinkTextAr: "للتحقق من بيانات التقرير يرجى زيارة موقع صحة الرسمي",
  visibleLinkTextEn: "To check the report please visit Seha's official website",
  englishFontFamily: "Georgia, 'Times New Roman', serif",
  englishFontSize: 13,
  englishFontWeight: 500,
  englishDirection: "ltr",
  englishAlign: "center",
  englishOffsetX: 0,
  englishOffsetY: 0,
  arabicOffsetX: 0,
  arabicOffsetY: 0,
  logoWidth: 96,
  logoOffsetX: 0,
  logoOffsetY: 0,
  barcodeWidth: 92,
  barcodeOffsetX: 0,
  barcodeOffsetY: 0,
  hideGuideLines: true,
  customFieldDefinitions: [],
};

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}
function englishDate(value: string) {
  if (!value) return "";
  return new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "2-digit", year: "numeric" }).format(new Date(`${value}T12:00:00`)).replaceAll("/", "-");
}
function longDate(value: string) {
  if (!value) return "";
  return new Intl.DateTimeFormat("en-US", { weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(new Date(`${value}T12:00:00`));
}
function hijriDate(value: string) {
  if (!value) return "";
  const parts = new Intl.DateTimeFormat("en-US-u-ca-islamic-umalqura-nu-latn", { day: "2-digit", month: "2-digit", year: "numeric" }).formatToParts(new Date(`${value}T12:00:00`));
  const day = parts.find(p => p.type === "day")?.value ?? "";
  const month = parts.find(p => p.type === "month")?.value ?? "";
  const year = parts.find(p => p.type === "year")?.value ?? "";
  return `${day}-${month}-${year}`;
}
function calculateDays(start: string, end: string) {
  if (!start || !end) return 0;
  const diff = Math.round((new Date(`${end}T12:00:00`).getTime() - new Date(`${start}T12:00:00`).getTime()) / 86400000);
  return Math.max(0, diff + 1);
}
function makeClientNumber(prefix: "GSL" | "PSL") {
  return `${prefix}${String(Math.floor(Math.random() * 100000000000)).padStart(11, "0")}`;
}
function initialReport(settings: Settings): ReportData {
  const date = "2026-09-11";
  return {
    reportNumber: "",
    sector: "government",
    durationDays: 1,
    startDate: date,
    endDate: date,
    issueDate: date,
    startHijri: hijriDate(date),
    endHijri: hijriDate(date),
    printTime: "12:53 AM",
    printDate: longDate(date),
    identityNumber: "1037115787",
    patientNameAr: "فاطمه محمد آل سالم",
    patientNameEn: "Fatima Muhammad Al Salem",
    nationalityAr: "السعودية",
    nationalityEn: "Saudi Arabia",
    employerAr: "مركز صحي السليمانية",
    employerEn: "",
    doctorNameAr: "خالدة الحسن عبدالله",
    doctorNameEn: "KHALIDA AL-HASSAN ABDULLAH",
    jobTitleAr: "طبيب عام",
    jobTitleEn: "General",
    facilityNameAr: settings.facilityNameAr,
    facilityNameEn: settings.facilityNameEn,
    visibleLinkTextAr: settings.visibleLinkTextAr,
    visibleLinkTextEn: settings.visibleLinkTextEn,
    hiddenLinkUrl: settings.verifyTargetUrl,
    barcodeUrl: settings.barcodeUrl,
    customFields: settings.customFieldDefinitions.map(field => ({ ...field, valueAr: "", valueEn: "" })),
  };
}

function Input({ label, value, onChange, dir = "rtl", type = "text", placeholder = "" }: { label: string; value: string | number; onChange: (value: string) => void; dir?: "rtl" | "ltr"; type?: string; placeholder?: string }) {
  return <label className="field"><span>{label}</span><input dir={dir} type={type} value={value} placeholder={placeholder} onChange={e => onChange(e.target.value)} /></label>;
}

function ReportSheet({ data, settings, reportRef }: { data: ReportData; settings: Settings; reportRef: React.RefObject<HTMLDivElement | null> }) {
  const rows = [
    ["Leave ID", "", data.reportNumber, "رمز الإجازة"],
    ["Duration", `${data.durationDays} day (${englishDate(data.startDate)} to ${englishDate(data.endDate)})`, `(${data.startHijri} إلى ${data.endHijri})  ${data.durationDays}`, "مدة الإجازة"],
    ["Admission Date", englishDate(data.startDate), data.startHijri, "تاريخ الدخول"],
    ["Discharge Date", englishDate(data.endDate), data.endHijri, "تاريخ الخروج"],
    ["Issue Date", englishDate(data.issueDate), "", "تاريخ إصدار التقرير"],
    ["Name", data.patientNameEn, data.patientNameAr, "الاسم"],
    ["National ID / Iqama", data.identityNumber, "", "رقم الهوية / الإقامة"],
    ["Nationality", data.nationalityEn, data.nationalityAr, "الجنسية"],
    ["Employer", data.employerEn, data.employerAr, "جهة العمل"],
    ["Practitioner Name", data.doctorNameEn, data.doctorNameAr, "اسم الممارس"],
    ["Position", data.jobTitleEn, data.jobTitleAr, "المسمى الوظيفي"],
    ...data.customFields.map(field => [field.labelEn, field.valueEn, field.valueAr, field.labelAr]),
  ];
  return <div className="sheet-wrap"><div ref={reportRef} className="report-sheet" style={{ backgroundImage: `url(${settings.backgroundUrl || BG_DEFAULT})` }}>
    <div className="report-table-overlay">
      {rows.map((row, index) => <div className={`report-row ${index === 1 ? "report-dark-row" : ""}`} key={row[0]}>
        <div className="report-cell english-title">{row[0]}</div>
        <div className="report-cell english-value" style={{ fontFamily: settings.englishFontFamily, fontSize: `${settings.englishFontSize}px`, fontWeight: settings.englishFontWeight, direction: settings.englishDirection, textAlign: settings.englishAlign, transform: `translate(${settings.englishOffsetX}px, ${settings.englishOffsetY}px)` }}>{row[1]}</div>
        <div className="report-cell arabic-value" style={{ transform: `translate(${settings.arabicOffsetX}px, ${settings.arabicOffsetY}px)` }}>{row[2]}</div>
        <div className="report-cell arabic-title">{row[3]}</div>
      </div>)}
    </div>
    <div className="bottom-left">
      {data.barcodeUrl || settings.barcodeUrl ? <img className="barcode" style={{ width: `${settings.barcodeWidth}px`, transform: `translate(${settings.barcodeOffsetX}px, ${settings.barcodeOffsetY}px)` }} src={data.barcodeUrl || settings.barcodeUrl} alt="barcode" /> : <div className="barcode-placeholder"><span>QR</span><small>أضف صورة الباركود من الإعدادات</small></div>}
      <div className="verify-ar">{data.visibleLinkTextAr}</div>
      <div className="verify-ar">الرسمي</div>
      <a className="verify-link" href={data.hiddenLinkUrl || settings.verifyTargetUrl} target="_blank" rel="noreferrer">{data.visibleLinkTextEn}</a>
      <a className="verify-link actual-link" href={data.hiddenLinkUrl || settings.verifyTargetUrl} target="_blank" rel="noreferrer">{data.hiddenLinkUrl || settings.verifyTargetUrl}</a>
    </div>
    <div className="facility-block">
      <img className="hospital-logo" style={{ width: `${settings.logoWidth}px`, transform: `translate(${settings.logoOffsetX}px, ${settings.logoOffsetY}px)` }} src={settings.hospitalLogoUrl || LOGO_DEFAULT} alt="hospital logo" />
      <div className="facility-ar">{data.facilityNameAr}</div>
      <div className="facility-en">{data.facilityNameEn}</div>
    </div>
    <div className="report-footer"><div>{data.printTime}</div><div>{data.printDate}</div></div>
  </div></div>;
}

export default function Home() {
  const settingsQuery = trpc.settings.get.useQuery();
  const reportsQuery = trpc.reports.list.useQuery();
  const saveReport = trpc.reports.save.useMutation({ onSuccess: () => { toast.success("تم حفظ التقرير في السجل"); reportsQuery.refetch(); }, onError: e => toast.error(e.message) });
  const generateNumber = trpc.reports.generateNumber.useMutation();
  const saveSettings = trpc.settings.save.useMutation({ onSuccess: () => { toast.success("تم حفظ الإعدادات بشكل دائم"); settingsQuery.refetch(); }, onError: e => toast.error(e.message) });
  const translateArabic = trpc.translation.arabicToEnglish.useMutation({ onSuccess: result => setTranslationEnglish(result), onError: e => toast.error(e.message) });
  const uploadAsset = trpc.settings.uploadAsset.useMutation();
  const [active, setActive] = useState<"editor" | "records" | "settings" | "translate">("editor");
  const [settings, setSettings] = useState<Settings>(defaultSettings);
  const [data, setData] = useState<ReportData>(() => initialReport(defaultSettings));
  const [recordId, setRecordId] = useState<number | undefined>();
  const [search, setSearch] = useState("");
  const [translation, setTranslation] = useState("");
  const [translationEnglish, setTranslationEnglish] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const reportRef = useRef<HTMLDivElement>(null);

  useEffect(() => { if (settingsQuery.data) { const next = { ...defaultSettings, ...(settingsQuery.data as Partial<Settings>) }; setSettings(next); setData(current => ({ ...current, facilityNameAr: current.facilityNameAr || next.facilityNameAr, facilityNameEn: current.facilityNameEn || next.facilityNameEn, visibleLinkTextAr: current.visibleLinkTextAr || next.visibleLinkTextAr, visibleLinkTextEn: current.visibleLinkTextEn || next.visibleLinkTextEn, hiddenLinkUrl: current.hiddenLinkUrl || next.verifyTargetUrl, barcodeUrl: current.barcodeUrl || next.barcodeUrl })); } }, [settingsQuery.data]);
  useEffect(() => { if (!data.reportNumber && !generateNumber.isPending) { generateNumber.mutate({ sector: data.sector }, { onSuccess: number => setData(current => ({ ...current, reportNumber: number })), onError: () => setData(current => ({ ...current, reportNumber: makeClientNumber(current.sector === "government" ? "GSL" : "PSL") })) }); } }, [data.reportNumber, data.sector]);

  const update = <K extends keyof ReportData>(key: K, value: ReportData[K]) => setData(current => ({ ...current, [key]: value }));
  const updateDate = (key: "startDate" | "endDate" | "issueDate", value: string) => {
    setData(current => ({ ...current, [key]: value, ...(key === "startDate" ? { startHijri: hijriDate(value) } : {}), ...(key === "endDate" ? { endHijri: hijriDate(value) } : {}), ...(key === "startDate" || key === "endDate" ? { durationDays: calculateDays(key === "startDate" ? value : current.startDate, key === "endDate" ? value : current.endDate) } : {}) }));
  };
  const visibleReports = useMemo(() => (reportsQuery.data ?? []).filter(row => row && `${row.reportNumber ?? ""} ${String((row.data as ReportData)?.patientNameAr ?? "")} ${String((row.data as ReportData)?.patientNameEn ?? "")}`.toLowerCase().includes(search.toLowerCase())), [reportsQuery.data, search]);
  const loadRecord = (row: any) => { setRecordId(row.id); setData({ ...initialReport(settings), ...(row.data as ReportData), reportNumber: row.reportNumber }); setActive("editor"); setMenuOpen(false); };
  const newReport = () => { setRecordId(undefined); setData(initialReport(settings)); setActive("editor"); setMenuOpen(false); };
  const save = () => { if (!/^(GSL|PSL)\d{11}$/.test(data.reportNumber)) { toast.error("رقم الإجازة يجب أن يبدأ بـ GSL أو PSL ويتبعه 11 رقمًا"); return; } saveReport.mutate({ id: recordId, reportNumber: data.reportNumber, data: { ...data } }); };
  const share = async () => { const text = `${data.reportNumber} — ${data.patientNameAr}\n${data.hiddenLinkUrl || settings.verifyTargetUrl}`; if (navigator.share) await navigator.share({ title: "تقرير إجازة مرضية", text, url: data.hiddenLinkUrl || settings.verifyTargetUrl }); else { await navigator.clipboard.writeText(text); toast.success("تم نسخ بيانات المشاركة"); } };
  const downloadPdf = async () => {
    if (!reportRef.current) return;
    toast.info("جاري تجهيز ملف PDF...");
    try {
      const [{ default: html2canvas }, { jsPDF }] = await Promise.all([import("html2canvas"), import("jspdf")]);
      const canvas = await html2canvas(reportRef.current, { scale: 2, useCORS: true, backgroundColor: "#ffffff" });
      const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
      pdf.addImage(canvas.toDataURL("image/png"), "PNG", 0, 0, 210, 297, undefined, "FAST");
      const linkX = 27; const linkY = 240; const linkW = 78; const linkH = 10;
      pdf.link(linkX, linkY, linkW, linkH, { url: data.hiddenLinkUrl || settings.verifyTargetUrl });
      pdf.save(`${data.reportNumber || "sick-leave-report"}.pdf`);
      toast.success("تم تنزيل التقرير بصيغة PDF");
    } catch (error) { console.error(error); toast.error("تعذر إنشاء PDF؛ استخدم خيار الطباعة ثم اختر حفظ كـ PDF"); window.print(); }
  };
  const upload = async (file: File, key: "hospitalLogoUrl" | "backgroundUrl" | "barcodeUrl") => {
    const base64 = await new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result).split(",")[1] || ""); reader.onerror = reject; reader.readAsDataURL(file); });
    uploadAsset.mutate({ filename: file.name, mimeType: file.type || "application/octet-stream", base64 }, { onSuccess: result => setSettings(current => ({ ...current, [key]: result.url })), onError: e => toast.error(e.message) });
  };
  const saveAllSettings = () => saveSettings.mutate(settings);

  return <div className="app-shell" dir="rtl">
    <aside className={`sidebar ${menuOpen ? "open" : ""}`}>
      <div className="brand"><div className="brand-mark">ص</div><div><strong>سجل الإجازات</strong><small>تقارير طبية احترافية</small></div><button className="icon-btn mobile-close" onClick={() => setMenuOpen(false)}><X size={18} /></button></div>
      <nav>
        <button className={active === "editor" ? "active" : ""} onClick={() => { setActive("editor"); setMenuOpen(false); }}><FileText size={18} /> تقرير جديد</button>
        <button className={active === "records" ? "active" : ""} onClick={() => { setActive("records"); setMenuOpen(false); }}><SlidersHorizontal size={18} /> السجل المحفوظ</button>
        <button className={active === "settings" ? "active" : ""} onClick={() => { setActive("settings"); setMenuOpen(false); }}><Settings2 size={18} /> الإعدادات</button>
        <button className={active === "translate" ? "active" : ""} onClick={() => { setActive("translate"); setMenuOpen(false); }}><Languages size={18} /> ترجمة عربي ← إنجليزي</button>
      </nav>
      <div className="sidebar-note"><span>حالة النظام</span><b><i /> جاهز للعمل</b><small>الإعدادات محفوظة تلقائيًا في السجل</small></div>
    </aside>
    {menuOpen && <div className="scrim" onClick={() => setMenuOpen(false)} />}
    <main className="main-content">
      <header className="topbar"><button className="icon-btn mobile-menu" onClick={() => setMenuOpen(true)}><Menu size={20} /></button><div><p className="eyebrow">لوحة التحكم</p><h1>{active === "editor" ? "إنشاء تقرير إجازة مرضية" : active === "records" ? "السجل المحفوظ" : active === "settings" ? "إعدادات النموذج" : "مساعد الترجمة"}</h1></div><div className="top-actions"><span className="status-pill"><i /> محفوظاتك آمنة</span><button className="button primary" onClick={newReport}><Plus size={17} /> تقرير جديد</button></div></header>
      {active === "editor" && <div className="workspace"><section className="panel editor-panel"><div className="panel-header"><div><span className="section-kicker">بيانات التقرير</span><h2>المعلومات القابلة للتعديل</h2></div><div className="panel-actions"><button className="button ghost" onClick={share}><Share2 size={16} /> مشاركة</button><button className="button outline" onClick={downloadPdf}><Download size={16} /> تنزيل PDF</button><button className="button primary" onClick={save} disabled={saveReport.isPending}><Save size={16} /> {saveReport.isPending ? "جارٍ الحفظ" : "حفظ في السجل"}</button></div></div>
        <div className="form-scroll">
          <div className="form-section"><div className="form-section-title"><span>01</span><h3>التوليد والتواريخ</h3></div><div className="form-grid three"><label className="field"><span>نوع القطاع</span><select value={data.sector} onChange={e => { const sector = e.target.value as ReportData["sector"]; update("sector", sector); update("reportNumber", makeClientNumber(sector === "government" ? "GSL" : "PSL")); }}><option value="government">حكومي — GSL</option><option value="private">خاص — PSL</option></select></label><label className="field"><span>رقم الإجازة (قابل للتعديل)</span><div className="input-with-button"><input dir="ltr" value={data.reportNumber} onChange={e => update("reportNumber", e.target.value.toUpperCase())} /><button className="mini-button" onClick={() => generateNumber.mutate({ sector: data.sector }, { onSuccess: number => update("reportNumber", number) })}>توليد</button></div></label><Input label="مدة الإجازة بالأيام" type="number" value={data.durationDays} onChange={value => update("durationDays", Number(value) || 0)} /></div><div className="form-grid three"><Input label="تاريخ الدخول ميلادي" type="date" value={data.startDate} onChange={value => updateDate("startDate", value)} /><Input label="تاريخ الخروج ميلادي" type="date" value={data.endDate} onChange={value => updateDate("endDate", value)} /><Input label="تاريخ إصدار التقرير" type="date" value={data.issueDate} onChange={value => updateDate("issueDate", value)} /></div><div className="form-grid two"><Input label="تاريخ الدخول هجري (قابل للتعديل)" value={data.startHijri} onChange={value => update("startHijri", value)} dir="ltr" /><Input label="تاريخ الخروج هجري (قابل للتعديل)" value={data.endHijri} onChange={value => update("endHijri", value)} dir="ltr" /></div></div>
          <div className="form-section"><div className="form-section-title"><span>02</span><h3>بيانات المريض</h3></div><div className="form-grid two"><Input label="الاسم بالعربي" value={data.patientNameAr} onChange={value => update("patientNameAr", value)} /><Input label="Patient name (English)" value={data.patientNameEn} onChange={value => update("patientNameEn", value)} dir="ltr" /><Input label="رقم الهوية / الإقامة" value={data.identityNumber} onChange={value => update("identityNumber", value)} dir="ltr" /><Input label="الجنسية بالعربي" value={data.nationalityAr} onChange={value => update("nationalityAr", value)} /><Input label="Nationality (English)" value={data.nationalityEn} onChange={value => update("nationalityEn", value)} dir="ltr" /><Input label="جهة العمل بالعربي" value={data.employerAr} onChange={value => update("employerAr", value)} /><Input label="Employer (English)" value={data.employerEn} onChange={value => update("employerEn", value)} dir="ltr" /></div></div>
          <div className="form-section"><div className="form-section-title"><span>03</span><h3>بيانات الممارس والمنشأة</h3></div><div className="form-grid two"><Input label="اسم الممارس بالعربي" value={data.doctorNameAr} onChange={value => update("doctorNameAr", value)} /><Input label="Practitioner name (English)" value={data.doctorNameEn} onChange={value => update("doctorNameEn", value)} dir="ltr" /><Input label="المسمى الوظيفي بالعربي" value={data.jobTitleAr} onChange={value => update("jobTitleAr", value)} /><Input label="Position (English)" value={data.jobTitleEn} onChange={value => update("jobTitleEn", value)} dir="ltr" /><Input label="اسم المنشأة بالعربي" value={data.facilityNameAr} onChange={value => update("facilityNameAr", value)} /><Input label="Facility name (English)" value={data.facilityNameEn} onChange={value => update("facilityNameEn", value)} dir="ltr" /></div></div>
          {data.customFields.length > 0 && <div className="form-section"><div className="form-section-title"><span>04</span><h3>الإضافات المحفوظة</h3></div><div className="form-grid two">{data.customFields.map((field, index) => <div className="custom-field-pair" key={`${field.labelAr}-${index}`}><Input label={field.labelAr} value={field.valueAr} onChange={value => setData(current => ({ ...current, customFields: current.customFields.map((item, itemIndex) => itemIndex === index ? { ...item, valueAr: value } : item) }))} /><Input label={field.labelEn} value={field.valueEn} onChange={value => setData(current => ({ ...current, customFields: current.customFields.map((item, itemIndex) => itemIndex === index ? { ...item, valueEn: value } : item) }))} dir="ltr" /></div>)}</div></div>}
          <div className="form-section"><div className="form-section-title"><span>05</span><h3>التحقق والوقت</h3></div><div className="form-grid two"><Input label="الرابط الظاهر بالعربي" value={data.visibleLinkTextAr} onChange={value => update("visibleLinkTextAr", value)} /><Input label="النص الظاهر بالإنجليزي" value={data.visibleLinkTextEn} onChange={value => update("visibleLinkTextEn", value)} dir="ltr" /><Input label="الرابط المخفي / الوجهة الفعلية" value={data.hiddenLinkUrl} onChange={value => update("hiddenLinkUrl", value)} dir="ltr" /><Input label="وقت إصدار التقرير" value={data.printTime} onChange={value => update("printTime", value)} dir="ltr" /><Input label="تاريخ الإصدار الظاهر أسفل التقرير" value={data.printDate} onChange={value => update("printDate", value)} dir="ltr" /></div><div className="hint">الرابط الظاهر داخل التقرير قابل للنقر، لكنه يفتح الرابط المخفي الذي تحدده هنا.</div></div>
        </div></section><section className="panel preview-panel"><div className="panel-header compact"><div><span className="section-kicker">معاينة مباشرة</span><h2>شكل التقرير</h2></div><span className="a4-badge">A4 · بدون خطوط حمراء</span></div><div className="preview-area"><ReportSheet data={data} settings={settings} reportRef={reportRef} /></div></section></div>}
      {active === "records" && <section className="panel records-panel"><div className="panel-header"><div><span className="section-kicker">أرشيف التقارير</span><h2>التقارير المحفوظة</h2></div><div className="search-box"><Search size={17} /><input placeholder="ابحث بالرقم أو الاسم" value={search} onChange={e => setSearch(e.target.value)} /></div></div><div className="records-list">{visibleReports.length === 0 ? <div className="empty-state"><FileText size={40} /><h3>لا توجد تقارير محفوظة بعد</h3><p>ابدأ بإنشاء تقرير جديد وسيظهر هنا تلقائيًا.</p><button className="button primary" onClick={newReport}><Plus size={16} /> إنشاء تقرير</button></div> : visibleReports.map((row: any) => <div className="record-card" key={row.id}><div className="record-icon"><FileText size={20} /></div><div className="record-main"><strong>{row.reportNumber}</strong><span>{(row.data as ReportData)?.patientNameAr || "بدون اسم"}</span><small>{(row.data as ReportData)?.issueDate || ""}</small></div><button className="button ghost" onClick={() => loadRecord(row)}><Pencil size={16} /> تعديل</button></div>)}</div></section>}
      {active === "settings" && <section className="panel settings-panel"><div className="panel-header"><div><span className="section-kicker">تحكم دائم</span><h2>إعدادات النموذج</h2></div><button className="button primary" onClick={saveAllSettings}><Save size={16} /> حفظ الإعدادات</button></div><div className="settings-grid"><div className="settings-card"><h3>النصوص الإنجليزية والاتجاهات</h3><p>اضبط الخط والمكان لجميع النصوص الإنجليزية في النموذج.</p><div className="form-grid two"><Input label="نوع الخط" value={settings.englishFontFamily} onChange={value => setSettings(s => ({ ...s, englishFontFamily: value }))} dir="ltr" /><Input label="حجم الخط" type="number" value={settings.englishFontSize} onChange={value => setSettings(s => ({ ...s, englishFontSize: Number(value) }))} /><Input label="الوزن" type="number" value={settings.englishFontWeight} onChange={value => setSettings(s => ({ ...s, englishFontWeight: Number(value) }))} /><label className="field"><span>اتجاه النص الإنجليزي</span><select value={settings.englishDirection} onChange={e => setSettings(s => ({ ...s, englishDirection: e.target.value as Settings["englishDirection"] }))}><option value="ltr">من اليسار لليمين</option><option value="rtl">من اليمين لليسار</option></select></label><label className="field"><span>محاذاة النص</span><select value={settings.englishAlign} onChange={e => setSettings(s => ({ ...s, englishAlign: e.target.value as Settings["englishAlign"] }))}><option value="left">يسار</option><option value="center">وسط</option><option value="right">يمين</option></select></label><Input label="إزاحة إنجليزي أفقيًا px" type="number" value={settings.englishOffsetX} onChange={value => setSettings(s => ({ ...s, englishOffsetX: Number(value) }))} /><Input label="إزاحة إنجليزي عموديًا px" type="number" value={settings.englishOffsetY} onChange={value => setSettings(s => ({ ...s, englishOffsetY: Number(value) }))} /><Input label="إزاحة عربي أفقيًا px" type="number" value={settings.arabicOffsetX} onChange={value => setSettings(s => ({ ...s, arabicOffsetX: Number(value) }))} /><Input label="إزاحة عربي عموديًا px" type="number" value={settings.arabicOffsetY} onChange={value => setSettings(s => ({ ...s, arabicOffsetY: Number(value) }))} /></div></div><div className="settings-card"><h3>الأصول المرئية</h3><p>غيّر الخلفية أو الشعار أو صورة الباركود في أي وقت.</p><AssetUpload label="خلفية التقرير" value={settings.backgroundUrl} accept="image/*" onUpload={file => upload(file, "backgroundUrl")} /><AssetUpload label="شعار المستشفى" value={settings.hospitalLogoUrl} accept="image/*" onUpload={file => upload(file, "hospitalLogoUrl")} /><AssetUpload label="صورة الباركود / QR" value={settings.barcodeUrl} accept="image/*" onUpload={file => upload(file, "barcodeUrl")} /><div className="form-grid two"><Input label="عرض الشعار px" type="number" value={settings.logoWidth} onChange={value => setSettings(s => ({ ...s, logoWidth: Number(value) }))} /><Input label="عرض الباركود px" type="number" value={settings.barcodeWidth} onChange={value => setSettings(s => ({ ...s, barcodeWidth: Number(value) }))} /><Input label="إزاحة الشعار أفقيًا" type="number" value={settings.logoOffsetX} onChange={value => setSettings(s => ({ ...s, logoOffsetX: Number(value) }))} /><Input label="إزاحة الشعار عموديًا" type="number" value={settings.logoOffsetY} onChange={value => setSettings(s => ({ ...s, logoOffsetY: Number(value) }))} /></div></div><div className="settings-card wide"><h3>إعدادات الإضافة والرابط</h3><p>هذه القيم الافتراضية تستمر مع كل تقرير جديد، ويمكن تعديلها لاحقًا.</p><div className="form-grid two"><Input label="اسم المنشأة بالعربي" value={settings.facilityNameAr} onChange={value => setSettings(s => ({ ...s, facilityNameAr: value }))} /><Input label="اسم المنشأة بالإنجليزي" value={settings.facilityNameEn} onChange={value => setSettings(s => ({ ...s, facilityNameEn: value }))} dir="ltr" /><Input label="نص التحقق بالعربي" value={settings.visibleLinkTextAr} onChange={value => setSettings(s => ({ ...s, visibleLinkTextAr: value }))} /><Input label="نص التحقق بالإنجليزي" value={settings.visibleLinkTextEn} onChange={value => setSettings(s => ({ ...s, visibleLinkTextEn: value }))} dir="ltr" /><Input label="الرابط المخفي الافتراضي" value={settings.verifyTargetUrl} onChange={value => setSettings(s => ({ ...s, verifyTargetUrl: value }))} dir="ltr" /></div><div className="custom-fields-manager"><div className="custom-fields-heading"><strong>إضافات النموذج</strong><button className="mini-button add-field" onClick={() => setSettings(s => ({ ...s, customFieldDefinitions: [...s.customFieldDefinitions, { labelAr: "حقل جديد", labelEn: "New field" }] }))}><Plus size={13} /> إضافة حقل</button></div>{settings.customFieldDefinitions.map((field, index) => <div className="custom-field-row" key={index}><input value={field.labelAr} onChange={e => setSettings(s => ({ ...s, customFieldDefinitions: s.customFieldDefinitions.map((item, itemIndex) => itemIndex === index ? { ...item, labelAr: e.target.value } : item) }))} placeholder="العنوان العربي" /><input dir="ltr" value={field.labelEn} onChange={e => setSettings(s => ({ ...s, customFieldDefinitions: s.customFieldDefinitions.map((item, itemIndex) => itemIndex === index ? { ...item, labelEn: e.target.value } : item) }))} placeholder="English label" /><button className="icon-btn remove-field" onClick={() => setSettings(s => ({ ...s, customFieldDefinitions: s.customFieldDefinitions.filter((_, itemIndex) => itemIndex !== index) }))}><X size={15} /></button></div>)}</div></div></div></section>}
      {active === "translate" && <section className="panel translate-panel"><div className="panel-header"><div><span className="section-kicker">أداة سريعة</span><h2>ترجمة عربي ← إنجليزي</h2></div></div><div className="translator"><div className="translation-box"><div className="box-label"><span>العربية</span><span>قابل للتحديد والنسخ</span></div><textarea value={translation} onChange={e => setTranslation(e.target.value)} placeholder="اكتب النص العربي هنا..." /></div><div className="translation-arrow"><button className="button primary translate-action" disabled={!translation.trim() || translateArabic.isPending} onClick={() => translateArabic.mutate({ text: translation })}>{translateArabic.isPending ? "..." : "ترجم"}</button></div><div className="translation-box english"><div className="box-label"><span>English</span><button className="copy-btn" onClick={() => { navigator.clipboard.writeText(translation); toast.success("تم النسخ"); }}>نسخ</button></div><textarea dir="ltr" value={translationEnglish} readOnly placeholder="ستظهر الترجمة هنا..." /></div></div><div className="hint">مربع الترجمة يدعم التحديد والنسخ، والترجمة الفعلية تتم عبر خدمة اللغة عند الضغط على زر «ترجم».</div></section>}
    </main>
  </div>;
}

function AssetUpload({ label, value, accept, onUpload }: { label: string; value: string; accept: string; onUpload: (file: File) => void }) {
  return <div className="asset-upload"><div><strong>{label}</strong><small>{value ? "تم اختيار أصل محفوظ" : "لم تتم الإضافة بعد"}</small></div><label className="upload-button"><Upload size={15} /> رفع<input type="file" accept={accept} onChange={e => { const file = e.target.files?.[0]; if (file) onUpload(file); }} /></label></div>;
}
