CREATE TABLE `sick_leave_settings` (
	`id` int NOT NULL,
	`data` text NOT NULL,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `sick_leave_settings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sick_leave_reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`reportNumber` varchar(32) NOT NULL,
	`data` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `sick_leave_reports_id` PRIMARY KEY(`id`),
	CONSTRAINT `sick_leave_reports_reportNumber_unique` UNIQUE(`reportNumber`)
);
