import { desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { appSettings, InsertUser, reports, Report, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export const DEFAULT_SETTINGS = {
  backgroundUrl: "/assets/report-background.png",
  hospitalLogoUrl: "/assets/seha_logo.png",
  barcodeUrl: "",
  facilityNameAr: "مستشفى الملك سلمان بالرياض",
  facilityNameEn: "King Salman Hospital In Riyadh",
  verifyTargetUrl: "https://seha.sa/#/i/inquiries/slenquiry",
  visibleLinkTextAr: "للتحقق من بيانات التقرير يرجى زيارة موقع صحة الرسمي",
  visibleLinkTextEn: "To check the report please visit Seha's official website",
  englishFontFamily: "Georgia, 'Times New Roman', serif",
  englishFontSize: 13,
  englishFontWeight: 500,
  englishDirection: "ltr",
  englishAlign: "center",
  englishOffsetX: 0,
  englishOffsetY: 0,
  arabicOffsetX: 0,
  arabicOffsetY: 0,
  logoWidth: 96,
  logoOffsetX: 0,
  logoOffsetY: 0,
  barcodeWidth: 92,
  barcodeOffsetX: 0,
  barcodeOffsetY: 0,
  hideGuideLines: true,
  customFieldDefinitions: [] as { labelAr: string; labelEn: string }[],
};

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  for (const field of ["name", "email", "loginMethod"] as const) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  values.lastSignedIn = user.lastSignedIn ?? new Date();
  updateSet.lastSignedIn = values.lastSignedIn;
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

function parseJson(value: string | null | undefined, fallback: Record<string, unknown>) {
  try {
    return value ? JSON.parse(value) : fallback;
  } catch {
    return fallback;
  }
}

export async function listReports() {
  const db = await getDb();
  if (!db) return [] as Report[];
  return db.select().from(reports).orderBy(desc(reports.updatedAt));
}

export async function getReport(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(reports).where(eq(reports.id, id)).limit(1);
  return result[0];
}

export async function getReportByNumber(reportNumber: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(reports).where(eq(reports.reportNumber, reportNumber)).limit(1);
  return result[0];
}

export async function saveReport(id: number | undefined, reportNumber: string, data: Record<string, unknown>) {
  const db = await getDb();
  if (!db) return { id: id ?? 0, reportNumber, data };
  const serialized = JSON.stringify(data);
  if (id) {
    await db.update(reports).set({ reportNumber, data: serialized }).where(eq(reports.id, id));
    return { id, reportNumber, data };
  }
  const inserted = await db.insert(reports).values({ reportNumber, data: serialized });
  return { id: Number(inserted[0].insertId), reportNumber, data };
}

export function decodeReport(row: Report | undefined) {
  if (!row) return undefined;
  return { ...row, data: parseJson(row.data, {}) };
}

export async function getSettings() {
  const db = await getDb();
  if (!db) return DEFAULT_SETTINGS;
  const result = await db.select().from(appSettings).where(eq(appSettings.id, 1)).limit(1);
  return { ...DEFAULT_SETTINGS, ...parseJson(result[0]?.data, {}) };
}

export async function saveSettings(data: Record<string, unknown>) {
  const merged = { ...DEFAULT_SETTINGS, ...data };
  const db = await getDb();
  if (!db) return merged;
  await db.insert(appSettings).values({ id: 1, data: JSON.stringify(merged) }).onDuplicateKeyUpdate({ set: { data: JSON.stringify(merged) } });
  return merged;
}
