import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { decodeReport, getReport, getReportByNumber, getSettings, listReports, saveReport, saveSettings } from "./db";
import { storagePut } from "./storage";
import { randomInt } from "node:crypto";
import { invokeLLM } from "./_core/llm";

const reportDataSchema = z.record(z.string(), z.any());

async function createUniqueNumber(prefix: "GSL" | "PSL") {
  for (let attempt = 0; attempt < 12; attempt++) {
    const number = `${prefix}${String(randomInt(0, 100000000000)).padStart(11, "0")}`;
    const existing = await getReportByNumber(number);
    if (!existing) return number;
  }
  throw new Error("تعذر توليد رقم فريد، حاول مرة أخرى");
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  reports: router({
    list: publicProcedure.query(async () => (await listReports()).map(decodeReport)),
    get: publicProcedure.input(z.object({ id: z.number().int().positive() })).query(async ({ input }) => decodeReport(await getReport(input.id))),
    getByNumber: publicProcedure.input(z.object({ reportNumber: z.string().min(3) })).query(async ({ input }) => decodeReport(await getReportByNumber(input.reportNumber))),
    generateNumber: publicProcedure.input(z.object({ sector: z.enum(["government", "private"]) })).mutation(async ({ input }) => createUniqueNumber(input.sector === "government" ? "GSL" : "PSL")),
    save: publicProcedure.input(z.object({ id: z.number().int().positive().optional(), reportNumber: z.string().regex(/^(GSL|PSL)\d{11}$/, "صيغة رقم الإجازة يجب أن تكون GSL أو PSL متبوعًا بـ 11 رقمًا"), data: reportDataSchema })).mutation(async ({ input }) => saveReport(input.id, input.reportNumber, input.data)),
  }),
  settings: router({
    get: publicProcedure.query(() => getSettings()),
    save: publicProcedure.input(reportDataSchema).mutation(({ input }) => saveSettings(input)),
    uploadAsset: publicProcedure.input(z.object({ filename: z.string().min(1), mimeType: z.string().min(1), base64: z.string().min(1) })).mutation(async ({ input }) => {
      const buffer = Buffer.from(input.base64, "base64");
      const extension = input.filename.split(".").pop()?.replace(/[^a-z0-9]/gi, "") || "bin";
      const { url, key } = await storagePut(`report-assets/${Date.now()}-${Math.random().toString(36).slice(2)}.${extension}`, buffer, input.mimeType);
      return { url, key };
    }),
  }),
  translation: router({
    arabicToEnglish: publicProcedure.input(z.object({ text: z.string().min(1).max(2000) })).mutation(async ({ input }) => {
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "Translate Arabic to clear professional English. Return only the translation, with no quotation marks or explanation." },
          { role: "user", content: input.text },
        ],
      });
      const content = response.choices?.[0]?.message?.content;
      if (typeof content === "string") return content.trim();
      if (Array.isArray(content)) return content.map(part => "text" in part ? part.text : "").join("").trim();
      return "";
    }),
  }),
});

export type AppRouter = typeof appRouter;
