import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function caller() {
  const ctx: TrpcContext = {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
  return appRouter.createCaller(ctx);
}

describe("sick leave report rules", () => {
  it("generates a government number with GSL plus eleven digits", async () => {
    const result = await caller().reports.generateNumber({ sector: "government" });
    expect(result).toMatch(/^GSL\d{11}$/);
  });

  it("generates a private number with PSL plus eleven digits", async () => {
    const result = await caller().reports.generateNumber({ sector: "private" });
    expect(result).toMatch(/^PSL\d{11}$/);
  });

  it("accepts editable report data when the number format is valid", async () => {
    const result = await caller().reports.save({
      reportNumber: "GSL12345678901",
      data: { patientNameAr: "اسم تجريبي", startHijri: "01-01-1448" },
    });
    expect(result.reportNumber).toBe("GSL12345678901");
    expect(result.data.patientNameAr).toBe("اسم تجريبي");
  });

  it("rejects report numbers with the wrong prefix or digit count", async () => {
    await expect(caller().reports.save({ reportNumber: "GSL123", data: {} })).rejects.toThrow();
    await expect(caller().reports.save({ reportNumber: "ABC12345678901", data: {} })).rejects.toThrow();
  });
});
