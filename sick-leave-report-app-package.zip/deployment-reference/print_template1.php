<?php
// print_template.php - نسخة خط Tinos الأصلي بالوزن الطبيعي النظيف لـ رقم 6 بدون عطفة

if (!isset($data)) die("Report not found");

if (!function_exists('h')) {
    function h($v) {
        return htmlspecialchars($v ?? "", ENT_QUOTES, "UTF-8");
    }
}

if (!function_exists('formatDateDMY')) {
    function formatDateDMY($date) {
        return $date ? date("d-m-Y", strtotime($date)) : "";
    }
}

// تحويل الأرقام العربية/الفارسية إلى إنجليزية
if (!function_exists('toEnglishDigits')) {
    function toEnglishDigits($text) {
        $eastern = ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩','۰','۱','۲','۳','۴','۵','۶','۷','٨','٩'];
        $western = ['0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9'];
        return str_replace($eastern, $western, $text);
    }
}

if (!function_exists('hijriDateClean')) {
    function hijriDateClean($date) {
        if (!$date || !class_exists("IntlDateFormatter")) return "";

        $fmt = new IntlDateFormatter(
            "ar_SA@calendar=islamic-umalqura",
            IntlDateFormatter::SHORT,
            IntlDateFormatter::NONE,
            "Asia/Riyadh",
            IntlDateFormatter::TRADITIONAL,
            "dd-MM-yyyy"
        );

        return toEnglishDigits($fmt->format(strtotime($date)));
    }
}

// مسار مباشر للصور
if (!function_exists('assetPath')) {
    function assetPath($file) {
        $path = __DIR__ . '/' . ltrim($file, '/');
        if (!file_exists($path)) return "";
        return $path;
    }
}

if (!function_exists('dateDMYtoYMD')) {
    function dateDMYtoYMD($date) {
        $date = trim($date ?? '');
        if ($date === '') return '';
        $parts = explode('-', $date);
        if (count($parts) !== 3) return $date;
        return $parts[2] . '-' . $parts[1] . '-' . $parts[0];
    }
}

if (!function_exists('textLen')) {
    function textLen($text) {
        $text = trim($text ?? '');
        if ($text === '') return 0;
        if (function_exists('mb_strlen')) return mb_strlen($text, 'UTF-8');
        preg_match_all('/./us', $text, $matches);
        return count($matches[0]);
    }
}

// البيانات الأساسية
$leaveCode       = toEnglishDigits(h($data["leave_code"]));
$idNumber        = toEnglishDigits(h($data["identity_number"]));

$startGregorian  = toEnglishDigits(formatDateDMY($data["start_date"]));
$endGregorian    = toEnglishDigits(formatDateDMY($data["end_date"]));
$issueGregorian  = toEnglishDigits(formatDateDMY($data["issue_date"]));

$startHijri      = hijriDateClean($data["start_date"]);
$endHijri        = hijriDateClean($data["end_date"]);

$startHijriYMD = dateDMYtoYMD($startHijri);
$endHijriYMD   = dateDMYtoYMD($endHijri);

$durationDays = (int)($data["duration_days"] ?? 0);

$durationEn = toEnglishDigits(
    $durationDays . " day (" . $startGregorian . " to " . $endGregorian . ")"
);

// الوقت والتاريخ أسفل التقرير
$printTime = "";
$printDate = "";

if (!empty($data["custom_datetime"]) && strpos($data["custom_datetime"], ' - ') !== false) {
    $datetime_parts = explode(' - ', $data["custom_datetime"]);
    $raw_time = trim($datetime_parts[0]);
    $raw_date = trim($datetime_parts[1]);

    $time_parsed = strtotime($raw_time);

    if ($time_parsed !== false) {
        $printTime = toEnglishDigits(date("g:i", $time_parsed)) . " " . date("A", $time_parsed);
    } else {
        $printTime = toEnglishDigits($raw_time);
    }

    $printDate = toEnglishDigits($raw_date);
} else {
    $default_source = !empty($data["issue_date"]) ? $data["issue_date"] : "";

    if (!empty($default_source)) {
        $timeObj = strtotime($default_source);

        if ($timeObj !== false) {
            $printTime = toEnglishDigits(date("g:i", $timeObj)) . " " . date("A", $timeObj);
            $printDate = date('l, j F Y', $timeObj);
        }
    }
}

// صور التقرير
$bgSrc          = assetPath('bg.png');
$barcodeSrc     = assetPath('barcode.png');
$defaultLogoSrc = assetPath('seha_logo.png');

$customLogoSrc = "";
if (!empty($data["hospital_logo"])) {
    $customLogoSrc = assetPath($data["hospital_logo"]);
}

$sehaLogoSrc = $customLogoSrc ?: $defaultLogoSrc;

// روابط خطوط Noto Sans Arabic
$notoSansRegularUrl = function_exists('findFontFile') ? findFontFile(['NotoSansArabic-Regular.ttf']) : assetPath('fonts/Noto_Sans_Arabic/static/NotoSansArabic-Regular.ttf');
$notoSansSemiBoldUrl = function_exists('findFontFile') ? findFontFile(['NotoSansArabic-SemiBold.ttf','NotoSansArabic-Bold.ttf','NotoSansArabic-Regular.ttf']) : assetPath('fonts/Noto_Sans_Arabic/static/NotoSansArabic-SemiBold.ttf');
$notoSansBoldUrl = function_exists('findFontFile') ? findFontFile(['NotoSansArabic-Bold.ttf','NotoSansArabic-ExtraBold.ttf','NotoSansArabic-SemiBold.ttf']) : assetPath('fonts/Noto_Sans_Arabic/static/NotoSansArabic-Bold.ttf');

// فحص النصوص الطويلة لتطبيق التصغير التلقائي الذكي
$patientNameEnClass = textLen($data["patient_name_en"] ?? "") > 24 ? "long-text-en" : "";
$patientNameArClass = textLen($data["patient_name_ar"] ?? "") > 20 ? "long-text-ar" : "";

$doctorNameEnClass  = textLen($data["doctor_name_en"] ?? "") > 24 ? "long-text-en" : "";
$doctorNameArClass  = textLen($data["doctor_name_ar"] ?? "") > 20 ? "long-text-ar" : "";

$employerEnClass    = textLen($data["employer_en"] ?? "") > 24 ? "long-text-en" : "";
$employerArClass    = textLen($data["employer_ar"] ?? "") > 18 ? "long-text-ar" : "";

$jobTitleEnClass    = textLen($data["job_title_en"] ?? "") > 24 ? "long-text-en" : "";
$jobTitleArClass    = textLen($data["job_title_ar"] ?? "") > 18 ? "long-text-ar" : "";

$nationalityEnClass = textLen($data["nationality_en"] ?? "") > 24 ? "long-text-en" : "";
$nationalityArClass = textLen($data["nationality_ar"] ?? "") > 18 ? "long-text-ar" : "";



<?php
// بيانات المريض، المنشأة، الإجازة، والوقت المخصص
$data = [
    // رمز الإجازة والمدة (إجازة اليوم فقط)
    "leave_code"        => "GSL12092026",
    "duration_days"     => 1,
    "start_date"        => "2026-09-12",
    "end_date"          => "2026-09-12",
    "issue_date"        => "2026-09-12",

    // الوقت أولاً ثم التاريخ بهذه الصيغة
    "custom_datetime"   => "12:13 AM - Saturday, 12 September 2026",

    // بيانات المريض
    "identity_number"   => "11122111221",
    "patient_name_ar"   => "جواد صادق احمد الحاج",
    "patient_name_en"   => "JAWAD SADIQ Ahmad AL-HAJJ",
    "nationality_ar"    => "سعودي",
    "nationality_en"    => "Saudi",
    "employer_ar"       => "إلى من يهمه الأمر",
    "employer_en"       => "To Whom It May Concern",

    // بيانات الممارس والمنشأة
    "doctor_name_ar"    => "أبو جودات السمعي",
    "doctor_name_en"    => "ABU JAWDAT ALHAJJ AL-SAMA'I",
    "job_title_ar"      => "طبيب عام",
    "job_title_en"      => "General",
    "hospital_name_ar"  => "مستشفى الملك فهد العام",
    "hospital_name_en"  => "King Fahad General Hospital",
    "hospital_logo"     => ""
];
?>


<style>
/* =========================================================
   1. تعريف الخطوط (Font Faces)
   ========================================================= */
@font-face {
    font-family: 'notosansarabic';
    src: url("<?= h($notoSansRegularUrl) ?>") format('truetype');
    font-weight: 450;
    font-style: normal;
    font-display: swap;
}
@font-face {
    font-family: 'notosansarabic';
    src: url("<?= h($notoSansSemiBoldUrl ?: $notoSansRegularUrl) ?>") format('truetype');
    font-weight: 600;
    font-style: normal;
    font-display: swap;
}
@font-face {
    font-family: 'notosansarabic';
    src: url("<?= h($notoSansBoldUrl ?: $notoSansSemiBoldUrl ?: $notoSansRegularUrl) ?>") format('truetype');
    font-weight: 700;
    font-style: normal;
    font-display: swap;
}
@font-face {
    font-family: 'AwamiNastaliq';
    src: url('fonts/AwamiNastaliq-3.400/AwamiNastaliq-Regular.woff2') format('woff2');
    font-weight: 400;
    font-style: normal;
    font-display: block;
    }
    
/* =========================================================
   2. إعدادات الصفحة العامة (Page & Body Setup)
   ========================================================= */
@page {
    margin: 0;
}
html, body {
    margin: 0;
    padding: 0;
    width: 210mm;
    min-height: 297mm;
    background: #fff;
    -webkit-print-color-adjust: exact !important;
    print-color-adjust: exact !important;
}
.page {
    width: 210mm;
    height: 297mm;
    margin: 0;
    padding-top: 38.4mm;
    box-sizing: border-box;
    overflow: hidden;
    background: url("<?= h($bgSrc) ?>") no-repeat 0 0;
    background-size: 210mm 297mm !important;
    background-image-resize: 6;
    position: relative;
}

/* =========================================================
   3. تنسيق وموازنة أبعاد الهيكل للجدول الأساسي
   ========================================================= */
.main-table {
    width: 194mm !important;   
    margin-left: 8mm !important; 
    margin-top: 21mm !important;
    border-collapse: collapse !important;
    table-layout: fixed !important;
    overflow: hidden !important;
}

/* ضبط ارتفاعات الخلايا والتمركز العمودي الكامل الكفاءة */
.main-table td {
    height: 10.65mm !important;
    min-height: 10.65mm !important;
    max-height: 10.65mm !important;
    padding-top: 0 !important;
    padding-bottom: 0 !important;
    vertical-align: middle !important;
    text-align: center !important;
    line-height: normal !important;
    background-color: transparent !important;
    box-sizing: border-box !important;
}

/* موازنة الصفوف بشكل منفصل وتام الدقة */
.main-table tr:nth-child(1) td { height: 10.75mm !important; max-height: 10.75mm !important; }
.main-table tr:nth-child(2) td { height: 10.25mm !important; max-height: 10.25mm !important; }
.main-table tr:nth-child(3) td { height: 10.7mm !important; max-height: 10.7mm !important; }
.main-table tr:nth-child(4) td { height: 10.7mm !important; max-height: 10.7mm !important; }
.main-table tr:nth-child(5) td { height: 10mm !important; max-height: 10mm !important; }
.main-table tr:nth-child(6) td { height: 11.1mm !important; max-height: 11.1mm !important; }
.main-table tr:nth-child(n+7) td { height: 10.5mm !important; max-height: 10.5mm !important; }

    
/* =========================================================
   تثبيت صارم وقاطع للعناوين والبيانات الثابتة (عربي + إنجليزي)
   ========================================================= */

/* 1. تثبيت العناوين الثابتة الإنجليزية (العمود الأول أقصى اليسار) */

/* 1. قفل العناوين الثابتة الإنجليزية (أقصى اليسار) */
.main-table td.col-title-en {
    font-family: "Century Expanded", "Century Schoolbook", Century, serif !important;
    direction: ltr !important;
    unicode-bidi: embed !important;
    color: #366fb5 !important;
    
    /* الحجم والوزن الثابت */
    font-size: 14px !important;         
    font-weight: 600 !important; 
    white-space: nowrap !important; /* منع الكلمة نهائياً من الانكماش أو النزول */
    
    /* نظام الجدول الأصلي المتوافق 100% مع محركات الـ PDF */
    display: table-cell !important;
    vertical-align: middle !important;
    text-align: center !important;
    
    /* قفل العرض أفقياً لمنع انقاص الحجم */

    
    /* قفل الارتفاع الموحد والآمن للطباعة */
    height: 10.5mm !important;
    max-height: 10.5mm !important;
    min-height: 10.5mm !important;
    line-height: 1.2 !important; /* استخدام نسبة مرنة للطباعة بدلاً من البكسل */
    
    overflow: hidden !important; 
    box-sizing: border-box !important;
    padding: 0 1mm !important;
    }
    
/* 2. تثبيت العناوين الثابتة العربية (العمود الرابع أقصى اليمين) */
.main-table td.col-title-ar {
    font-family: 'Noto Sans Arabic', 'notosansarabic', Arial, sans-serif !important;
    direction: rtl !important;
    unicode-bidi: embed !important;
    color: #366fb5 !important;
    
    /* قفل الحجم والوزن الثابت للعنوان العربي */
    font-size: 13.5px !important;
    font-weight: 700 !important;
    white-space: nowrap !important; /* إجبار الكلمة مثل (المسمى الوظيفي) تبقى على سطر واحد ثابت */
    
    /* هندسة التمركز والحظر */
    display: table-cell !important;
    vertical-align: middle !important;
    text-align: center !important;
    
    /* قفل الارتفاع الموحد بالملي */
    height: 10.5mm !important;
    max-height: 10.5mm !important;
    min-height: 10.5mm !important;
    padding: 0 2mm !important;
    box-sizing: border-box !important;
    overflow: hidden !important;
    }
    

    /* =========================================================
   الضبط الصارم للعناوين والبيانات الإنجليزية (توسط كامل وحظر الخروج)
   ========================================================= */

/* النصوص المتغيرة الإنجليزية (الاسم، الطبيب، المسمى، الجنسية، جهة العمل) */
/* النصوص المتغيرة الإنجليزية (الاسم، الطبيب، المسمى، الجنسية، جهة العمل) - خط Century Expanded */
.data-en {
    /* استدعاء خط Century Expanded مع البدائل المتطابقة هندسياً في أنظمة التشغيل */
    font-family: "Century Expanded", "Century Schoolbook", Century, serif !important; 
    font-style: normal !important;        /* هذا السحر يعطيك نفس الميلان الأنيق والممتد لخط الأوامي */
    direction: ltr !important;
    unicode-bidi: embed !important;
    color: #2c3e76 !important;
    font-weight: 200 !important;         /* عريض ومتناسق مع وزن التواريخ */
    font-size: 13px !important;         /* حجم مثالي ومطابق تماماً لحجم الجدول */
    
    /* إجبار النص على الالتفاف والانقسام لسطرين بمرونة */
    white-space: normal !important;      
    overflow-wrap: break-word !important; 
    word-break: normal !important;
    
    /* التوسط العمودي والأفقي الصارم في السنتر تماماً */
    display: table-cell !important;
    vertical-align: middle !important;
    text-align: center !important;
    
    /* تثبيت الارتفاع كمكبح صارم لمنع مط الجدول لأسفل الصفحة */
    height: 10.5mm !important;
    max-height: 10.5mm !important;
    min-height: 10.5mm !important;
    
    /* يمكنك التحكم بتقريب أو تبيعد السطرين هنا بالبكسل وسيتجاوب معك فوراً وبدون أي حدود مخفية */
    line-height: 13px !important; 
    
    overflow: hidden !important;   /* حظر خروج الكلمات خارج الخلية */
    box-sizing: border-box !important;
    padding: 0 1mm !important;
    }
    
    

/* السحر هنا: التحكم بالمسافة والتصاق السطرين تماماً تحت بعضهما */
.data-en .line-top,
.data-en .line-bottom {
    display: block !important;
    white-space: nowrap !important;
    width: 100% !important;
    text-align: center !important;
    /* سحبنا الـ line-height لأقل درجة ممكنة لمنع تباعد الحروف */
    line-height: 10px !important; 
    height: 4.5mm !important;
}

/* سحب السطر الثاني ليلتصق تماماً بالسطر الأول ويفصل الحقول الثابتة */
.data-en .line-bottom {
    margin-top: -3px !important; /* يمكنك زيادة السحب لـ -4px أو -5px ليلتصق أكثر حسب رغبتك */
}

    
    
/* =========================================================
   4. إدارة الخطوط والألوان والتقسيم لسطرين (Word Wrap Patch)
   ========================================================= */



/* العناوين الثابتة - العربية */
.col-title-ar {
    font-family: 'Noto Sans Arabic', 'notosansarabic', Arial, sans-serif !important;
    direction: rtl !important;
    unicode-bidi: embed !important;
    font-size: 13.5px !important;
    font-weight: 600 !important;
    color: #366fb5 !important;
    white-space: nowrap !important;
}


/* النصوص المتغيرة العربية الموحدة تماماً (بمن فيهم خط الجنسية الحالي) */
.data-ar {
    font-family: 'Noto Sans Arabic', 'notosansarabic', Arial, sans-serif !important;
    direction: rtl !important;
    unicode-bidi: embed !important;
    color: #2c3e77 !important;
    font-weight: 500 !important;
    font-size: 13.2px !important;
    white-space: normal !important;      /* إجبار التقرير على قبول سطرين */
    overflow-wrap: break-word !important; 
    word-break: normal !important;
    line-height: 4.4mm !important;
}
/* =========================================================
   5. ميزة الكيانات المصغرة عند إدخال نصوص ضخمة جداً (Auto-Shrink Rules)
   ========================================================= */

/* التمركز المتناسق المباشر داخل جميع خلايا الجدول وقفل الارتفاع عمودياً */
.data-en, .data-ar, .col-title-en, .col-title-ar, .date-cell {
    display: table-cell !important;
    vertical-align: middle !important; /* سنترة عمودية حقيقية غصب عن المحرك */
    text-align: center !important;
    height: 10.5mm !important;
    max-height: 10.5mm !important;
    min-height: 10.5mm !important;
    box-sizing: border-box !important;
}

/* =========================================================
   6. التواريخ والأرقام الخاصة بـ AwamiNastaliq (تثبيت كامل بدون تحريك يدوّي)
   ========================================================= */
.num-awami {
    font-family: 'AwamiNastaliq', serif !important;
    font-weight: 400 !important;
    font-size: 14.4px !important;
    line-height: 10.5mm !important; /* إجبار الرقم على أخذ الارتفاع الكامل والسنترة في المنتصف */
    display: block !important;       /* تحويله لكتلة لضمان استجابة السنترة */
    white-space: nowrap !important;
    color: #2c3e77 !important;
}

/* إلغاء حركات السحب العشوائية التي تسبب سقوط الأرقام عند التنزيل */
.date-cell .num-awami, 
.id-number-cell .num-awami, 
.leave-code-cell .num-awami {
    transform: none !important; /* إلغاء الترحيل العمودي الضار */
    margin: 0 auto !important;
}

.date-cell {
    vertical-align: middle !important;
    line-height: 10.5mm !important;
}

/* =========================================================
   7. شريط مدة الإجازة الملون بالأبيض بالكامل (Duration Highlights)
   ========================================================= */

/* استهداف مباشر وقوي لكل الخلايا والوسوم بداخل صف المدة لضمان تبييضها كلياً */
.main-table tr.row-highlight td,
.main-table tr.row-highlight td span,
.main-table tr.row-highlight td .col-title-en,
.main-table tr.row-highlight td .col-title-ar,
.main-table tr.row-highlight td .duration-en,
.main-table tr.row-highlight td .duration-ar-clean,
.main-table tr.row-highlight td .num-awami,
.main-table tr.row-highlight td .data-en {
    color: #ffffff !important;
}
    
.row-highlight .duration-en, 
.row-highlight .duration-ar-clean {
    font-family: 'AwamiNastaliq', serif !important;
    font-size: 14.4px !important;
    font-weight: 400 !important;
    line-height: 10.5mm !important; /* ضبط السنترة لصف المدة */
    vertical-align: middle !important;
}

.row-highlight .duration-en .num-awami {
    font-size: 14.4px !important;
    font-weight: 400 !important;
    line-height: 10.5mm !important;
    color: #ffffff !important;
    transform: none !important;
}

.duration-ar-clean {
    font-family: 'AwamiNastaliq', serif !important;
    direction: rtl !important;
    unicode-bidi: embed !important;
    text-align: center !important;
    font-size: 14.4px !important;
    white-space: nowrap !important;
}

/* =========================================================
   تثبيت نهائي وأخير: رفع الأرقام والتواريخ لأعلى وإلى نص الخلية تماماً
   ========================================================= */

/* =========================================================
   التعديل الهندسي النهائي والشامل لثبات الجدول والسنترة (المتصفح + PDF)
   ========================================================= */

/* =========================================================
   الضبط النهائي الصارم لسنترة الأرقام والتواريخ (اللمسة الأخيرة)
   ========================================================= */

/* 1. ضبط التمركز داخل الخلايا المدمجة (رقم الإجازة، الهوية، تاريخ الإصدار) */
.main-table td[colspan],
.main-table tr td.data-en[colspan="2"],
.main-table tr td[colspan="4"] {
    display: table-cell !important;
    vertical-align: middle !important; /* سنترة عمودية حقيقية */
    text-align: center !important;
    
    height: 10.5mm !important;
    max-height: 10.5mm !important;
    min-height: 10.5mm !important;
    
    /* إضافة مسافة أمان علوية لمنع الحروف من لمس الإطار العلوي */
    padding-top: 1.5mm !important; 
    padding-bottom: 0 !important;
    box-sizing: border-box !important;
}

/* 2. إجبار أرقام خط الأوامي والـ span على التوسط الكامل دون ارتفاع سطري خانق */
.main-table td .num-awami,
.main-table td[colspan] span,
.main-table td[colspan] center,
.date-cell .num-awami, 
.id-number-cell .num-awami, 
.leave-code-cell .num-awami {
    display: inline-block !important;
    vertical-align: middle !important;
    
    /* استخدام نسبة مرنة تلغي الانضغاط والقَص من الأسفل */
    line-height: 1.2 !important; 
    
    transform: none !important; /* إنهاء أي سحب قديم قد يؤدي لخلل التوازن */
    margin: 0 auto !important;
}

/* 3. ضبط خلايا التواريخ الجانبية العادية لمنع قص الأرقام الهجرية والميلادية */
.date-cell {
    vertical-align: middle !important;
    padding-top: 1mm !important; /* توازن مرئي دقيق جداً */
    box-sizing: border-box !important;
    }
    
    
/* =========================================================
   🚨 تعديل خاص: رفع رقم الهوية وتاريخ الإصدار لوسط الخلية تماماً 🚨
   ========================================================= */

/* 1. استهداف خلايا رقم الهوية وتاريخ إصدار التقرير (الخلايا المدمجة في هذه الصفوف) */
.main-table tr:nth-child(5) td[colspan], /* افتراضياً صف تاريخ الإصدار */
.main-table tr:nth-child(7) td[colspan], /* افتراضياً صف رقم الهوية */
.main-table td.id-number-cell, 
.main-table td.leave-code-cell {
    vertical-align: middle !important;
    /* تقليص أي مسافة علوية زائدة كانت تدفعهم لأسفل */
    padding-top: 0mm !important; 
    padding-bottom: 2mm !important; /* دفع خفيف من الأسفل للأعلى */
    box-sizing: border-box !important;
}

/* 2. السحب المغناطيسي للأرقام والنصوص بداخل هذه الخلايا لرفعها لفوق */
.main-table tr:nth-child(5) td[colspan] span,
.main-table tr:nth-child(7) td[colspan] span,
.main-table tr:nth-child(5) td[colspan] center,
.main-table tr:nth-child(7) td[colspan] center {
    display: inline-block !important;
    vertical-align: middle !important;
    
    /* السحر هنا: سحب رقم الهوية وتاريخ الإصدار للأعلى ليتوسطوا الخلية بالملي */
    margin-top: 0.5px !important; 
    line-height: 1 !important;
    }
    
    
/* =========================================================
   8. منطقة أسفل الصفحة (Footer Configuration)
   ========================================================= */
.bottom-area { margin-top: 4.8mm; width: 184mm; margin-left: 6mm; overflow: hidden; }
.left-side { float: left; width: 85mm; margin-left: 8mm; }
.qr-box { width: 24mm; height: 24mm; margin: -2 auto 2mm auto; }
.qr-image { width: 24mm; height: 24mm; display: block; }

.verify-text, .verify-section, .verify-section *, .verify-link-box {
    width: 95mm;
    margin: 2mm 0mm 0mm -4mm !important; 
    text-align: center;
    color: #000000 !important;
}
.verify-ar {
    width: 95mm;
    height: auto;
    text-align: center;
    margin: 2mm 0mm 0mm -4mm !important; 
    font-family: 'Noto Sans Arabic', 'notosansarabic', Arial, sans-serif !important;
    font-weight: 700 !important;
    font-size: 13px !important;
    line-height: 2 !important;
    margin-bottom: 3px !important;
}
.verify-en {
    font-family: tinos, "Times New Roman", serif;
    font-size: 10.5px;
    font-weight: bold;
    text-align: center;
    line-height: 1.55 !important;
    margin-top: 2px !important;
    margin-bottom: 3px !important;
    margin: 2mm 0mm 0mm -4mm !important; 
}
.verify-link {
    font-family: tinos, "Times New Roman", serif;
    font-size: 10.1px;
    font-weight: bold;
    direction: ltr;
    text-align: center;
    text-decoration: underline !important;
    
    /* ===== السحر هنا لتكبير منطقة الضغط سطر بسطر ===== */
    display: inline-block !important; /* تحويله لكتلة مرنة تسمح بالتمدد */
    padding-top: 8px !important;      /* زيادة مساحة الضغط من الأعلى سطر بسطر */
    padding-bottom: 8px !important;   /* زيادة مساحة الضغط من الأسفل سطر بسطر */
    padding-left: 15px !important;    /* مساحة ضغط جانبية مريحة */
    padding-right: 15px !important;   /* مساحة ضغط جانبية مريحة */
    
    cursor: pointer !important;       /* إظهار علامة اليد بمجرد الاقتراب من المنطقة الكبيرة */
    }
    
.org-info { float: right; width: 70mm; text-align: center; direction: rtl; margin-top: 2.5mm; font-size: 13.5px; line-height: 1.65; font-family: notosansarabic, Arial, sans-serif; font-weight: 550; }
.logo-box { width: 25mm; height: 21mm; margin: 1mm auto 2mm auto; overflow: hidden; }
.hospital-logo { max-width: 22mm; max-height: 21mm; width: auto; height: auto; display: block; margin: 2px auto; }

.org-info-ar, .hospital-ar-name {
    text-align: center;
    direction: rtl;
    height: auto !important;
    min-height: 6mm !important;
    line-height: 1.25 !important;
    overflow: visible !important;
    margin-top: 0.5mm !important;
    font-family: notosansarabic, Arial, sans-serif !important;
    font-size: 13px !important;
    font-weight: 600 !important;
    color: #000000 !important; 
}
.org-info-en { direction: ltr; font-family: tinos, "Times New Roman", serif; font-weight: 600; text-align: center; font-size: 13.2px; line-height: 1.6; color: #000000 !important; }
.print-info { clear: both; padding-top: 10mm; margin-left: 6mm; font-family: tinos, "Times New Roman", serif; font-size: 12px; color: #000000 !important; line-height: 1.7; direction: ltr; }

/* حظر الصور الملغاة */
.ar-cell-img, .ar-cell-img-small, .hospital-name-ar-img, .verify-ar-img {
    display: none !important;
}
    
    
    
    
    
/* ===== توحيد لون صف مدة الإجازة بالكامل إلى اللون الأبيض (الثابت والمتغير) ===== */

/* 1. تلوين العناوين الثابتة (العربي والإنجليزي) في صف المدة باللون الأبيض */
.row-highlight .col-title-en,
.row-highlight .col-title-ar {
    color: #ffffff !important;
}

/* 2. تلوين البيانات المتغيرة (العربي والإنجليزي والتواريخ) في صف المدة باللون الأبيض */
.row-highlight .duration-en,
.row-highlight .duration-ar-clean,
.row-highlight .num-awami,
.row-highlight .data-en {
    color: #ffffff !important;
    }

    
    
/* =========================================================
   🚨 كود مؤقت: حدود حمراء لكشف هيكل الجدول وخلاياه بالكامل 🚨
   ========================================================= */
/* إطار الجدول بالكامل */
.main-table {
    border: 1px solid rgba(255, 0, 0, 0.4) !important;
    border-collapse: collapse !important;
}

/* كل حقل وخلية داخل الجدول */
.main-table td {
    border: 1px solid rgba(255, 0, 0, 0.35) !important;
}

/* محتوى كل خانة داخلياً لمعرفة الهوامش */
.cell-wrapper {
    border: 1px dashed rgba(255, 0, 0, 0.25) !important;
}

/* مربع الباركود لوحده */
.qr-box {
    border: 1px solid rgba(255, 0, 0, 0.6) !important;
    min-height: 20px;
}

/* مربع الرابط لوحده */
.verify-link-box {
    border: 1px solid rgba(255, 0, 0, 0.6) !important;
}

/* مربع بيانات المستشفى لوحده */
.org-info {
    border: 1px solid rgba(255, 0, 0, 0.6) !important;
}

/* مربع الشعار لوحده */
.logo-box {
    border: 1px solid rgba(255, 0, 0, 0.6) !important;
    min-height: 20px;
}

/* مربع وقت وتاريخ الطباعة لوحده */
.print-info {
    border: 1px solid rgba(255, 0, 0, 0.6) !important;
}



</style>





<div class="page">
<table class="main-table">
   <colgroup>
        <col style="width: 21.3% !important;">
        <col style="width: 30.8% !important;">
        <col style="width: 31.2% !important;">
        <col style="width: 16.7% !important;">
    </colgroup>

    <tr>
        <td class="col-title-en">Leave ID</td>
        <td class="data-en leave-code-cell" colspan="2">
            <span class="num-awami"><?= $leaveCode ?></span>
        </td>
        <td class="col-title-ar">رمز الإجازة</td>
    </tr>

    <tr class="row-highlight">
        <td class="col-title-en">Duration</td>
        <td class="data-en duration-en">
            <span class="num-awami"><?= h($durationEn) ?></span>
        </td>
        <td class="data-ar duration-ar-clean">
            <?= toEnglishDigits($durationDays) ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(<?= h($startHijri) ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?= h($endHijri) ?>)
        </td>
        <td class="col-title-ar">مدة الإجازة</td>
    </tr>

    <tr>
        <td class="col-title-en">Admission Date</td>
        <td class="data-en date-cell">
            <span class="num-awami"><?= h($startGregorian) ?></span>
        </td>
        <td class="data-en date-cell">
            <span class="num-awami"><?= h($startHijri) ?></span>
        </td>
        <td class="col-title-ar">تاريخ الدخول</td>
    </tr>

    <tr>
        <td class="col-title-en">Discharge Date</td>
        <td class="data-en date-cell">
            <span class="num-awami"><?= h($endGregorian) ?></span>
        </td>
        <td class="data-en date-cell">
            <span class="num-awami"><?= h($endHijri) ?></span>
        </td>
        <td class="col-title-ar">تاريخ الخروج</td>
    </tr>

    <tr class="row-issue">
        <td class="col-title-en">Issue Date</td>
        <td class="data-en date-cell" colspan="2">
            <span class="num-awami"><?= h($issueGregorian) ?></span>
        </td>
        <td class="col-title-ar">تاريخ إصدار التقرير</td>
    </tr>

    <tr class="row-name">
        <td class="col-title-en">Name</td>
        <td class="data-en <?= $patientNameEnClass ?>"><?= h($data["patient_name_en"]) ?></td>
        <td class="data-ar <?= $patientNameArClass ?>"><?= h($data["patient_name_ar"]) ?></td>
        <td class="col-title-ar">الاسم</td>
    </tr>

    <tr class="row-id">
        <td class="col-title-en">National ID / Iqama</td>
        <td class="data-en id-number-cell" colspan="2">
            <span class="num-awami"><?= $idNumber ?></span>
        </td>
        <td class="col-title-ar">رقم الهوية / الإقامة</td>
    </tr>
    
    <tr class="row-nationality">
        <td class="col-title-en">Nationality</td>
        <td class="data-en <?= $nationalityEnClass ?>"><?= h($data["nationality_en"]) ?></td>
        <td class="data-ar <?= $nationalityArClass ?>"><?= h($data["nationality_ar"]) ?></td>
        <td class="col-title-ar">الجنسية</td>
    </tr>

    <tr class="row-employer">
        <td class="col-title-en">Employer</td>
        <td class="data-en <?= $employerEnClass ?>"><?= h($data["employer_en"]) ?></td>
        <td class="data-ar <?= $employerArClass ?>"><?= h($data["employer_ar"]) ?></td>
        <td class="col-title-ar">جهة العمل</td>
    </tr>

    <tr class="row-practitioner">
        <td class="col-title-en">Practitioner Name</td>
        <td class="data-en <?= $doctorNameEnClass ?>"><?= h($data["doctor_name_en"]) ?></td>
        <td class="data-ar <?= $doctorNameArClass ?>"><?= h($data["doctor_name_ar"]) ?></td>
        <td class="col-title-ar">اسم الممارس</td>
    </tr>

    <tr class="row-position">
        <td class="col-title-en">Position</td>
        <td class="data-en <?= $jobTitleEnClass ?>"><?= h($data["job_title_en"]) ?></td>
        <td class="data-ar <?= $jobTitleArClass ?>"><?= h($data["job_title_ar"]) ?></td>
        <td class="col-title-ar">المسمى الوظيفي</td>
    </tr>
</table>

<div class="bottom-area">
    <div class="left-side">
        <div class="qr-box">
            <?php if ($barcodeSrc): ?>
                <img src="<?= h($barcodeSrc) ?>" class="qr-image">
            <?php endif; ?>
        </div>
        
       <div class="verify-text">
            <div class="verify-ar">للتحقق من بيانات التقرير يرجى التأكد من زيارة موقع صحة<br>الرسمي</div>
            <div class="verify-en">To check the report please visit Seha's official website</div>
            <div class="verify-link-box">
                <a href="https://slenquiry-seha-sa.42web.io/in-121.html" class="verify-link">https://seha.sa/#/i/inquiries/slenquiry</a>
            </div>
       </div>
    </div>

    <div class="org-info">
        <div class="logo-box">
            <?php if ($sehaLogoSrc): ?>
                <img src="<?= h($sehaLogoSrc) ?>" class="hospital-logo">
            <?php endif; ?>
        </div>
        <div class="org-info-ar"><?= h($data["hospital_name_ar"]) ?></div>
        <div class="org-info-en"><?= h($data["hospital_name_en"]) ?></div>
   <div class="org-info-license" style="font-size: 11.5px; font-weight: 600; color: #000000; margin-top: 2px;">رقم الترخيص: 123546787976</div>
    </div>
    
    <div class="print-info">
        <div><?= h($printTime) ?></div>
        <div><?= h($printDate) ?></div>
    </div>
</div>
</div>

